
$(document).ready(function(){
	$('#singlebox').selectator();
	   
	$('#phone2').usPhoneFormat({
			format: '(xxx) xxx-xxxx',
	});
	
	$("#phone2").on("countrySelect", function(e, i){
	});

	$('#fullpage').fullpage({
		
		autoScrolling:true,
		anchors:['section_1', 'section_2', 'section_3','section_4','section_5','section_6'],
		
		keyboardScrolling: true,

		afterLoad:function(anchorLink ,index, destination ){

		if(index.index ==1){
			$('.circle_img').addClass('anm');
		
		}if(index.index ==2){
			$('.cr_imges').addClass('anm');

		}

		if(index.index ==3){
			$('.cr_img').addClass('anm');

		}

	},



	});
	

	
})

